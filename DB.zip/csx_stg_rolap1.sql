-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: csx_stg
-- ------------------------------------------------------
-- Server version	5.7.32-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `rolap1`
--

DROP TABLE IF EXISTS `rolap1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rolap1` (
  `Category` varchar(80) DEFAULT NULL,
  `SubCategory` varchar(80) NOT NULL,
  `City` varchar(30) DEFAULT NULL,
  `State` varchar(30) DEFAULT NULL,
  `Married_amount` int(40) DEFAULT NULL,
  `YearExpenses` decimal(7,2) DEFAULT NULL,
  `age` float(10,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rolap1`
--

LOCK TABLES `rolap1` WRITE;
/*!40000 ALTER TABLE `rolap1` DISABLE KEYS */;
INSERT INTO `rolap1` VALUES ('Gin\r','Navy Strength',NULL,NULL,50,43516.40,36),('Wine\r','Red medium dry',NULL,NULL,50,41837.60,36),('Rum\r','Spiced',NULL,NULL,50,53097.12,39),('Vodka\r','Flavoured 40%',NULL,NULL,50,50028.59,39),('Vodka\r','Flavoured 50%',NULL,NULL,50,49498.04,40),('Tequila\r','Rested',NULL,NULL,50,51507.14,38),('Gin\r','London dry',NULL,NULL,50,50075.13,39),('Gin\r','Old Tom',NULL,NULL,50,53392.16,39),('Wine\r','Red dry',NULL,NULL,50,51689.85,40),('Rum\r','Darked',NULL,NULL,50,51889.37,39),('Beer\r','Lager 7%',NULL,NULL,50,50041.81,40),('Tequila\r','Aged',NULL,NULL,50,50003.74,41),('Whiskey\r','Blended',NULL,NULL,50,50145.09,39),('Beer\r','Lager 5%',NULL,NULL,50,51340.87,40),('Beer\r','Ale 5%',NULL,NULL,50,40914.37,36),('Vodka\r','Premium 40%',NULL,NULL,50,40506.30,36),('Beer\r','Ale 7%',NULL,NULL,50,52130.36,40),('Rum\r','White',NULL,NULL,50,43435.42,38),('Tequila\r','Gold',NULL,NULL,50,43089.94,35),('Vodka\r','Premium 50%',NULL,NULL,50,50332.88,39),('Whiskey\r','Japanese ',NULL,NULL,50,50226.24,39),('Whiskey\r','Scotch',NULL,NULL,50,42164.83,36),('Whiskey\r','Irish',NULL,NULL,50,51665.14,40),('Gin\r','New Western Dry',NULL,NULL,50,51246.03,40),('Whiskey\r','Bourbon ',NULL,NULL,50,51921.67,40),('Wine\r','White dry',NULL,NULL,50,52101.34,40),('Wine\r','White medium dry',NULL,NULL,50,49198.15,39);
/*!40000 ALTER TABLE `rolap1` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-01-06 22:14:10
