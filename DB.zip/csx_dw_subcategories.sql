-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: csx_dw
-- ------------------------------------------------------
-- Server version	5.7.32-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `subcategories`
--

DROP TABLE IF EXISTS `subcategories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subcategories` (
  `Category` varchar(80) DEFAULT NULL,
  `SubCategory` varchar(80) NOT NULL,
  `DW_Sub_Category` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`DW_Sub_Category`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subcategories`
--

LOCK TABLES `subcategories` WRITE;
/*!40000 ALTER TABLE `subcategories` DISABLE KEYS */;
INSERT INTO `subcategories` VALUES ('Tequila\r','Aged',1),('Beer\r','Ale 5%',2),('Beer\r','Ale 7%',3),('Whiskey\r','Blended',4),('Whiskey\r','Bourbon ',5),('Rum\r','Darked',6),('Vodka\r','Flavoured 40%',7),('Vodka\r','Flavoured 50%',8),('Tequila\r','Gold',9),('Whiskey\r','Irish',10),('Whiskey\r','Japanese ',11),('Beer\r','Lager 5%',12),('Beer\r','Lager 7%',13),('Gin\r','London dry',14),('Gin\r','Navy Strength',15),('Gin\r','New Western Dry',16),('Gin\r','Old Tom',17),('Vodka\r','Premium 40%',18),('Vodka\r','Premium 50%',19),('Wine\r','Red dry',20),('Wine\r','Red medium dry',21),('Tequila\r','Rested',22),('Whiskey\r','Scotch',23),('Rum\r','Spiced',24),('Rum\r','White',25),('Wine\r','White dry',26),('Wine\r','White medium dry',27);
/*!40000 ALTER TABLE `subcategories` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-01-06 22:14:00
