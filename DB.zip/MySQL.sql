	create database csx_oltp;
    create database csx_MIR;
    create database csx_STG;
    create database csx_DW;
    
    DROP TABLE IF EXISTS csx_oltp.ProductsInOrder;
	DROP TABLE IF EXISTS csx_oltp.Deliveries;
    DROP TABLE IF EXISTS csx_oltp.products;
	DROP TABLE IF EXISTS csx_oltp.Suppliers;
	DROP TABLE IF EXISTS csx_oltp.SubCategories;
	DROP TABLE IF EXISTS csx_oltp.Orders;
    DROP TABLE IF EXISTS csx_oltp.ShippingMethods;
    DROP TABLE IF EXISTS csx_oltp.Preferences;
    DROP TABLE IF EXISTS csx_oltp.customers;
     DROP TABLE IF EXISTS csx_oltp.Suppliers;
    
	CREATE TABLE csx_oltp.ShippingMethods (
	ShippingMethod varchar(20),
	PRIMARY KEY (ShippingMethod) );
	Insert into csx_oltp.ShippingMethods (ShippingMethod) values ('Air');
    Insert into csx_oltp.ShippingMethods (ShippingMethod) values ('AirExpress');
    Insert into csx_oltp.ShippingMethods (ShippingMethod) values ('Train');
	
	CREATE TABLE  csx_oltp.customers (
	Email varchar (50),
	FirstName varchar (30),
	LastName varchar (30),
    Gender varchar (6),
    DOB datetime,
	PhoneNumber varchar (20),
	PRIMARY KEY (Email) ) ;
LOAD DATA LOCAL INFILE 'C:\\Users\\accout\\Desktop\\final DATA\\CustomersCSV.csv' INTO TABLE csx_oltp.customers FIELDS TERMINATED BY ',' IGNORE 1 LINES
(Email,FirstName,LastName,Gender,@var_col5,PhoneNumber)
SET DOB = STR_TO_DATE(@var_col5,'%m/%d/%Y');

	CREATE TABLE csx_oltp.SubCategories (
	SubCategory varchar (20),
	Category varchar (20),
	PRIMARY KEY (SubCategory) ) ;
    LOAD DATA LOCAL INFILE 'C:\\Users\\accout\\Desktop\\data\\SubCategories CSV.csv' INTO TABLE csx_oltp.SubCategories FIELDS TERMINATED BY ',' IGNORE 1 LINES;

  
CREATE TABLE csx_oltp.Orders (
	OrderID int,
    OrderDate date,
    ShippingMethod varchar(20),
    Address varchar(30),
    City varchar(15),
    State varchar(15),
	Email varchar (50),
	PRIMARY KEY (OrderID),
	FOREIGN KEY (ShippingMethod) REFERENCES csx_oltp.ShippingMethods(ShippingMethod),
    FOREIGN KEY (Email) REFERENCES csx_oltp.Customers(Email))  ;
	LOAD DATA LOCAL INFILE 'C:\\Users\\accout\\Desktop\\data\\Orders CSV update 1.csv' INTO TABLE csx_oltp.Orders FIELDS TERMINATED BY ',' IGNORE 1 LINES
(OrderID,@col2,ShippingMethod,Address,City,State,Email)
SET OrderDate = STR_TO_DATE(@col2,'%m/%d/%Y');

insert into csx_oltp.Orders (OrderID,OrderDate,ShippingMethod,Address,City,State,Email) 
values (4352,'2017/02-23','AirExpress',	'Angel  Drive, 4374'	,'Paris',	'Maryland',	'Javier_Emmett7756@liret.org');


	
CREATE TABLE csx_oltp.Suppliers (
	SupplierID int,
	SName varchar (20),
    PhoneNumber varchar (30),
	PRIMARY KEY (SupplierID) ) ;
     LOAD DATA LOCAL INFILE 'C:\\Users\\accout\\Desktop\\final DATA\\Suppliers CSV.csv' INTO TABLE csx_oltp.Suppliers FIELDS TERMINATED BY ',' IGNORE 1 LINES;

    
    
CREATE TABLE csx_oltp.products (
	SKU varchar (30),
	Category varchar (20),
    SubCategory varchar(20),
	Brand varchar (30),
	OriginCountry varchar (30),
    Price decimal (10,2),
	SupplierID int,
    AmountInStock int,
	PRIMARY KEY (SKU),
    FOREIGN KEY (SubCategory) REFERENCES csx_oltp.SubCategories(SubCategory),
	FOREIGN KEY (SupplierID) REFERENCES csx_oltp.Suppliers(SupplierID)) ;
      LOAD DATA LOCAL INFILE 'C:\\Users\\accout\\Desktop\\final DATA\\Products CSV.csv' INTO TABLE csx_oltp.Suppliers FIELDS TERMINATED BY ',' IGNORE 1 LINES;



CREATE TABLE csx_oltp.Deliveries (
	SKU varchar (20),
    DT date,
    Quantity int,
	PRIMARY KEY (SKU,DT),
	FOREIGN KEY (SKU) REFERENCES csx_oltp.products(SKU)) ;


	
	CREATE TABLE csx_oltp.ProductsInOrder (
    OrderID int,
	SKU varchar(30),
    Quantity int,
	PRIMARY KEY (OrderID,SKU),
	FOREIGN KEY (OrderID) REFERENCES csx_oltp.Orders(OrderID),
	FOREIGN KEY (SKU) REFERENCES csx_oltp.Products(SKU) );
    
    
	CREATE TABLE csx_oltp.Preferences(
    PID int,
	State varchar(30),
    City varchar(30) ,
    DOB date,
    MaritialStatus varchar(30),
    PreferredDrink varchar(30),
    YearExpenses decimal(7,2),
	PRIMARY KEY (PID) ) ;
          LOAD DATA LOCAL INFILE 'C:\\Users\\accout\\Desktop\\final DATA\\Prefernces csv.csv' INTO TABLE csx_oltp.Suppliers FIELDS TERMINATED BY ',' IGNORE 1 LINES;

    
    
    
    
 